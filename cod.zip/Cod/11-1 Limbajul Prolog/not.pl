nott(P) :- P, !, fail.
nott(P).